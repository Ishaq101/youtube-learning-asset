from pypdf import PdfReader as _PdfReader


class PdfReader:
    def read(self, file_path: str) -> list[str]:
        reader = _PdfReader(file_path)
        return [page.extract_text() or "" for page in reader.pages]
