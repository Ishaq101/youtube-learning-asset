import os

from app.reader.pdf_reader import PdfReader


class Reader:
    def __init__(self):
        self.readers = {
            ".pdf": PdfReader(),
        }

    def read(self, file_path: str) -> list[str]:
        ext = os.path.splitext(file_path)[1].lower()
        reader = self.readers.get(ext)
        if reader is None:
            raise ValueError(f"Unsupported file type: {ext}")
        return reader.read(file_path)
