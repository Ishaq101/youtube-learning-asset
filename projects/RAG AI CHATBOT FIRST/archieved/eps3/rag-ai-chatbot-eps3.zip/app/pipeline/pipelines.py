from dotenv import load_dotenv

from app.chunking.chunker import Chunker
from app.embedding.embedder import Embedder
from app.pipeline.ingestion_pipeline import IngestionPipeline
from app.provider.gemini.gemini import Gemini
from app.reader.reader import Reader
from app.vectordb.qdrant_client import get_qdrant_client


class Pipeline:
    def __init__(self):
        load_dotenv() # load credential dari file .env

        gemini = Gemini()
        self.ingestion = IngestionPipeline(
            reader=Reader(),
            chunker=Chunker(method="page", chunk_size=1, chunk_overlap=0),
            embedder=Embedder(gemini),
            vector_db=get_qdrant_client(),
        )

    def run_ingestion(self, source_path: str, collection_name: str = "documents") -> None:
        print(f"Ingesting {source_path}")
        self.ingestion.run(source_path, collection_name)
