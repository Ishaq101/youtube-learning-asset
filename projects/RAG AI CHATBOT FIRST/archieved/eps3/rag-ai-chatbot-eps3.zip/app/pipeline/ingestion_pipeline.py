import os
from pathlib import Path

from app.chunking.chunker import Chunker
from app.embedding.embedder import Embedder
from app.reader.reader import Reader
from app.vectordb.qdrant_client import QdrantVectorDB
from app.vectordb.schema import DocumentChunk


class IngestionPipeline:
    def __init__(self, reader: Reader, chunker: Chunker, embedder: Embedder, vector_db: QdrantVectorDB):
        self.reader = reader
        self.chunker = chunker
        self.embedder = embedder
        self.vector_db = vector_db

    def run(self, file_path: str, collection_name: str) -> None:
        source_path = Path(file_path)
        if source_path.is_file():
            file_paths = [source_path]
        elif source_path.is_dir():
            file_paths = sorted(
                path for path in source_path.iterdir()
                if path.is_file() and path.suffix.lower() == ".pdf"
            )
        else:
            raise FileNotFoundError(f"File or directory not found: {file_path}")

        document_chunks = []
        for path in file_paths:
            pages = self.reader.read(str(path))
            doc_name = os.path.basename(path)

            if self.chunker.method == "page":
                chunks = self.chunker.chunk(pages)
                for chunk_number, chunk in enumerate(chunks):
                    document_chunks.append(
                        DocumentChunk(
                            doc_name=doc_name,
                            page=chunk_number * (self.chunker.chunk_size - self.chunker.chunk_overlap) + 1,
                            chunk_number=chunk_number,
                            text=chunk,
                            vector=self.embedder.embed(chunk),
                        )
                    )
                continue

            for page_number, page_text in enumerate(pages, start=1):
                for chunk_number, chunk in enumerate(self.chunker.chunk(page_text)):
                    document_chunks.append(
                        DocumentChunk(
                            doc_name=doc_name,
                            page=page_number,
                            chunk_number=chunk_number,
                            text=chunk,
                            vector=self.embedder.embed(chunk),
                        )
                    )

        if not document_chunks:
            return

        self.vector_db.create_collection(collection_name, vector_size=len(document_chunks[0].vector))
        self.vector_db.ingest(collection_name, document_chunks)
