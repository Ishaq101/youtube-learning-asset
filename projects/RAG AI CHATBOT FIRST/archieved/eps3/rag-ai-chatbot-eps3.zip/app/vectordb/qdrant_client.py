import os

from qdrant_client import QdrantClient
from qdrant_client.http import models

from app.vectordb.schema import DocumentChunk


class QdrantVectorDB:
    def __init__(self, url: str | None = None, api_key: str | None = None):
        self.url = url or os.getenv("QDRANT_ENDPOINT")
        self.api_key = api_key or os.getenv("QDRANT_API_KEY")
        self.client: QdrantClient | None = None

    def connect(self) -> None:
        self.client = QdrantClient(url=self.url, api_key=self.api_key)

    def disconnect(self) -> None:
        if self.client is not None:
            self.client.close()
            self.client = None

    def create_collection(self, collection_name: str, vector_size: int, distance: models.Distance = models.Distance.COSINE) -> None:
        if not self.client.collection_exists(collection_name):
            self.client.create_collection(
                collection_name=collection_name,
                vectors_config=models.VectorParams(size=vector_size, distance=distance),
            )

    def ingest(self, collection_name: str, chunks: list[DocumentChunk]) -> None:
        self.client.upsert(collection_name=collection_name, points=[chunk.to_point() for chunk in chunks])

    def flush(self, collection_name: str) -> None:
        if self.client.collection_exists(collection_name):
            self.client.delete_collection(collection_name)

    def query(self, collection_name: str, query_vector: list[float], top_k: int = 5) -> list[models.ScoredPoint]:
        return self.client.query_points(
            collection_name=collection_name,
            query=query_vector,
            limit=top_k,
        ).points


_instance: QdrantVectorDB | None = None


def get_qdrant_client() -> QdrantVectorDB:
    global _instance
    if _instance is None:
        _instance = QdrantVectorDB()
        _instance.connect()
    return _instance
