import uuid

from pydantic import BaseModel
from qdrant_client.http.models import PointStruct


class DocumentChunk(BaseModel):
    doc_name: str
    page: int
    chunk_number: int
    text: str
    vector: list[float]

    @property
    def chunk_id(self) -> str:
        return f"{self.doc_name}:{self.page}:{self.chunk_number}"

    def to_point(self) -> PointStruct:
        point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, self.chunk_id))
        return PointStruct(
            id=point_id,
            vector=self.vector,
            payload={"doc_name": self.doc_name,
                     "chunk_id": self.chunk_id,
                     "page": self.page,
                     "text": self.text},
        )
