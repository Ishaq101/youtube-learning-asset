from typing import Protocol


class EmbeddingProvider(Protocol):
    def embed(self, text: str) -> list[float]: ...


class Embedder:
    def __init__(self, provider: EmbeddingProvider):
        self.provider = provider

    def embed(self, text: str) -> list[float]:
        return self.provider.embed(text)

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        return [self.provider.embed(text) for text in texts]
