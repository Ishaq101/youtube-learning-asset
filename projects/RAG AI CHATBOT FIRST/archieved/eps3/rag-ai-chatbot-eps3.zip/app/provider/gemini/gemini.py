import os

from google import genai

from app.provider.gemini.llm import GeminiLLM
from app.provider.gemini.model_embedding import GeminiEmbedding


class Gemini:
    def __init__(self, api_key: str | None = None, llm_model: str = "gemini-3.5-flash-lite", embedding_model: str = "gemini-embedding-2"):
        self.client = genai.Client(api_key=api_key or os.getenv("GEMINI_API_KEY"))
        self.llm = GeminiLLM(self.client, model=llm_model)
        self.embedding = GeminiEmbedding(self.client, model=embedding_model)

    def generate(self, prompt: str) -> str:
        return self.llm.generate(prompt)

    def embed(self, text: str) -> list[float]:
        return self.embedding.embed(text)
