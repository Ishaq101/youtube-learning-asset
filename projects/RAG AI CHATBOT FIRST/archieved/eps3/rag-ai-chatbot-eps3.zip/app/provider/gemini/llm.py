from google import genai


class GeminiLLM:
    def __init__(self, client: genai.Client, model: str = "gemini-3.5-flash-lite"):
        self.client = client
        self.model = model

    def generate(self, prompt: str) -> str:
        response = self.client.models.generate_content(model=self.model, contents=prompt)
        return response.text
