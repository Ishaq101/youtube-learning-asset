import time

from google import genai


class GeminiEmbedding:
    def __init__(
        self,
        client: genai.Client,
        model: str = "gemini-embedding-2",
        min_interval_seconds: float = 0.65,
    ):
        self.client = client
        self.model = model
        self.min_interval_seconds = min_interval_seconds
        self._last_request_at = 0.0

    def embed(self, text: str) -> list[float]:
        elapsed = time.monotonic() - self._last_request_at
        remaining_delay = self.min_interval_seconds - elapsed

        if remaining_delay > 0:
            time.sleep(remaining_delay)

        self._last_request_at = time.monotonic()
        response = self.client.models.embed_content(model=self.model, contents=text) # embedding dilakukan dari line ini
        return response.embeddings[0].values
