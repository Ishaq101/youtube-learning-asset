import re


class Chunker:
    def __init__(self, method: str = "sentence", chunk_size: int = 15, chunk_overlap: int = 1):
        if chunk_size <= 0:
            raise ValueError("chunk_size must be greater than 0")
        if chunk_overlap < 0:
            raise ValueError("chunk_overlap must be greater than or equal to 0")
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")

        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.methods = {
            "char": self._chunk_by_char,
            "word": self._chunk_by_word,
            "sentence": self._chunk_by_sentence,
            "page": self._chunk_by_page,
        }
        if method not in self.methods:
            raise ValueError(f"Unsupported chunk method: {method}")
        self.method = method

    def chunk(self, text: str | list[str]) -> list[str]:
        if self.method == "page":
            if not isinstance(text, list):
                raise TypeError("The page chunking method expects a list of page texts")
            return self._chunk_by_page(text)

        return self.methods[self.method](text)

    def _chunk_by_char(self, text: str) -> list[str]:
        step = self.chunk_size - self.chunk_overlap
        return [text[i:i + self.chunk_size] for i in range(0, len(text), step) if text[i:i + self.chunk_size]]

    def _chunk_by_word(self, text: str) -> list[str]:
        words = text.split()
        step = self.chunk_size - self.chunk_overlap
        return [" ".join(words[i:i + self.chunk_size]) for i in range(0, len(words), step) if words[i:i + self.chunk_size]]

    def _chunk_by_sentence(self, text: str) -> list[str]:
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]
        step = self.chunk_size - self.chunk_overlap
        return [" ".join(sentences[i:i + self.chunk_size]) for i in range(0, len(sentences), step) if sentences[i:i + self.chunk_size]]

    def _chunk_by_page(self, pages: list[str]) -> list[str]:
        step = self.chunk_size - self.chunk_overlap
        return [
            "\n".join(page for page in pages[i:i + self.chunk_size] if page.strip())
            for i in range(0, len(pages), step)
            if any(page.strip() for page in pages[i:i + self.chunk_size])
        ]
