from app.pipeline.pipelines import Pipeline

COLLECTION_NAME = "documents"
SOURCE_PATH = "documents"
TEST_SOURCE_PATH = "documents/RAG Implementation Guide.pdf"


def main():
    pipeline = Pipeline()
    pipeline.run_ingestion(SOURCE_PATH, COLLECTION_NAME)


if __name__ == "__main__":
    main()
