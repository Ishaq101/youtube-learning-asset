# RAG AI Chatbot

Proyek ini merupakan pipeline dasar **Retrieval-Augmented Generation (RAG)** untuk memproses dokumen PDF. Teks dari dokumen dibaca dan dipecah menjadi beberapa bagian (*chunks*), kemudian setiap bagian dibuatkan embedding menggunakan Google Gemini dan disimpan ke Qdrant sebagai vector database.

Pipeline ini menjadi fondasi untuk membangun chatbot yang dapat mencari informasi relevan dari dokumen sebelum menghasilkan jawaban.

## Arsitektur

![Arsitektur RAG](images/architecture.png)

## Menjalankan

1. Buat file `.env` dan tambahkan API key Gemini:

   ```env
   GEMINI_API_KEY=your_api_key
   ```

2. Jalankan pipeline ingestion:

   ```bash
   uv run main.py
   ```

Dokumen sumber tersedia di folder `documents/`.


## Sample Pertanyaan
1. Bagaimana alur lengkap pipeline RAG mulai dari ingestion dokumen, chunking, embedding, vector retrieval, hingga pembuatan jawaban oleh LLM?
2. Mengapa kualitas retrieval lebih penting daripada hanya menggunakan model LLM yang lebih besar, dan bagaimana chunking, overlap, Top-K, hybrid search, serta reranking memengaruhi kualitas jawaban?
3. Jika pengguna bertanya dalam bahasa Indonesia sementara dokumen menggunakan bahasa Inggris, bagaimana cara meningkatkan kemungkinan dokumen yang tepat dapat ditemukan?
4. Bagaimana cara mendiagnosis masalah ketika dokumen yang relevan sebenarnya ada, tetapi tidak muncul dalam hasil retrieval?
5. Bagaimana merancang sistem RAG production-ready yang mampu mengurangi hallucination, menyediakan citation, menerapkan access control, serta tetap efisien dari sisi latency, token, dan biaya?
